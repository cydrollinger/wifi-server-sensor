#ifndef __PRINTF_H__
#define __PRINTF_H__
int printf(const char *format, ...);
int sprintf(char *out, const char *format, ...);
#endif

