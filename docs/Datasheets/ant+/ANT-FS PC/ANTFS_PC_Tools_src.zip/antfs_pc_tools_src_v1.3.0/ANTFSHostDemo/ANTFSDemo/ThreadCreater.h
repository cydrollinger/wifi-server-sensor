/////////////////////////////////////////////////////////////////////////////////////////
// THE FOLLOWING EXAMPLE CODE IS INTENDED FOR LIMITED CIRCULATION ONLY.
// 
// Please forward all questions regarding this code to ANT Technical Support.
// 
// Dynastream Innovations Inc.
// 228 River Avenue
// Cochrane, Alberta, Canada
// T4C 2C1
// 
// (P) (403) 932-9292
// (F) (403) 932-6521
// (TF) 1-866-932-9292
// (E) support@thisisant.com
// 
// www.thisisant.com
//
// Reference Design Disclaimer
//
// The references designs and codes provided may be used with ANT devices only and remain the copyrighted property of 
// Dynastream Innovations Inc. The reference designs and codes are being provided on an "as-is" basis and as an accommodation, 
// and therefore all warranties, representations, or guarantees of any kind (whether express, implied or statutory) including, 
// without limitation, warranties of merchantability, non-infringement,
// or fitness for a particular purpose, are specifically disclaimed.
//
// �2009 Dynastream Innovations Inc. All Rights Reserved
// This software may not be reproduced by
// any means without express written approval of Dynastream
// Innovations Inc.
//
/////////////////////////////////////////////////////////////////////////////////////////
#pragma once

#include "dsi_thread.h"
#include <vcclr.h>


namespace ANTFSDemo
{
	ref class Form1;
}

//all unmanaged
DSI_THREAD_RETURN ResponseThreadStart(void* pvParam_);

////////////////////////////////////////////////////////////////////////////////////
// class ThreadCreater
//
// Wrapper used to created an unmanaged thread from managed code.
////////////////////////////////////////////////////////////////////////////////////
class ThreadCreater
{
public:
   ThreadCreater(ANTFSDemo::Form1^ pclForm1_)
	{
		pclForm1 = pclForm1_;
	}
	
	~ThreadCreater()
	{
	}
	
	DSI_THREAD_ID NewResponseThread()
	{
		return DSIThread_CreateThread(&ResponseThreadStart, this);
	}
	
	gcroot<ANTFSDemo::Form1^> pclForm1;
};
