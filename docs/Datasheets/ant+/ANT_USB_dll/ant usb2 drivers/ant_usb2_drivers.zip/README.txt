ANT LibUsb Windows Drivers
Current Release: 11 April 2012

The Ant LibUsb drivers install the neccesary drivers to use your Ant USB Stick 2 or USB-m.
If you have an internet connection the drivers will also install any value added software
that has been enabled by the stick vendor. 
If the vendor has not enabled any downloads, for development and OEM sticks,
or if you do not have an internet connection,
no software will be downloaded and you will have to obtain 
the software to use your Ant device on your own 
(ie: download AntWareII from thisisant.com developer zone).

Note: If you do not have an internet connection an error will appear telling you the 
value-added software was not installed. However, at this point, the driver itself is 
still installed succesfully, the device will show as such in the device manager, 
and it will function correctly in applications that access libusb devices.

These drivers are certified and signed by Microsoft. If you receive a message stating the
drivers are not signed, you are not using the official released version.

This driver is available automatically through windows update.

The actual drivers are the libusb-win32 drivers version 1.2.40. 
Libusb-win32 is a library that allows userspace application to access USB 
devices on a Win98SE/WinME/Win2k/WinXP/Win Vista/Win 7 OS on x86/x64/IA64.
It is derived from and fully API compatible to libusb available at 
http://libusb.sourceforge.net.
The libusb-win32 libraries/dlls are licensed under the LGPL.
For more information visit the project's web site at:
http://libusb-win32.sourceforge.net
http://sourceforge.net/projects/libusb-win32



