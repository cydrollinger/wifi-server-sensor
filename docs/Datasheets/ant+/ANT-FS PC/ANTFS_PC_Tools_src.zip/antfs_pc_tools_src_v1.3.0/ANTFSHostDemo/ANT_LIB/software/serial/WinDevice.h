#ifndef WINDEVICE_H
#define WINDEVICE_H

#include <types.h>
#include <windows.h>

#define INSTANCEID_PREFIX_CHAR TEXT('@') // character used to prefix instance ID's
#define CLASS_PREFIX_CHAR      TEXT('=') // character used to prefix class name
#define WILD_CHAR              TEXT('*') // wild character
#define QUOTE_PREFIX_CHAR      TEXT('\'') // prefix character to ignore wild characters
#define SPLIT_COMMAND_SEP      TEXT(":=") // whole word, indicates end of id's


int WinDevice_Enable(int argc,TCHAR* argv[]);
int WinDevice_Disable(int argc,TCHAR* argv[]);

//
// exit codes
//
#define EXIT_OK      (0)
#define EXIT_REBOOT  (1)
#define EXIT_FAIL    (2)
#define EXIT_USAGE   (3)

#endif //WINDEVICE_H_
