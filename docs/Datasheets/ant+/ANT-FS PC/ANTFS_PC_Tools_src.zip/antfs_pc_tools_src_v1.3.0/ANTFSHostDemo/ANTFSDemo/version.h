/*
 * Dynastream Innovations Inc.
 * Cochrane, AB, CANADA
 *
 * Copyright � 1998-2007 Dynastream Innovations Inc.
 * All rights reserved. This software may not be reproduced by
 * any means without express written approval of Dynastream
 * Innovations Inc.
 */ 

#if !defined(VERSION_H)
#define VERSION_H

#include "types.h"


// Version Information
#define APP_SW_VER_PPP                     "AML"
#define APP_SW_VER_NUM                     "1.3"
#define APP_SW_VER_DEV                     "00"
#define APP_SW_VER_BRANCH                  ""
#define APP_SW_VER                         APP_SW_VER_PPP APP_SW_VER_NUM APP_SW_VER_DEV APP_SW_VER_BRANCH


#endif // !defined(CONFIG_H)
