ANT USB Stick 2 Windows Drivers
Initial Release: 8 July 2011

The AntUsbStick2 drivers install the neccesary drivers to use your Ant Stick.
If you have an internet connection the drivers will also install any value added software
that has been enabled by the stick vendor. 
Usually for development and OEM sticks no software is downloaded and you will have to obtain 
the software to use your Ant Stick on your own 
(ie: download AntWareII from thisisant.com developer zone)

Note: If you do not have an internet connection an error will appear telling you the 
software was not installed, however the driver is still installed succesfully
and the device will appear installed properly in the device manager and will 
function correctly in applications that access libusb devices

These drivers are certified and signed by Microsoft. If you receive a message stating the
drivers are not signed, you are not using the official released version.

This driver is available automatically through windows update.

The actual drivers are the libusb-win32 drivers version 0.1.12.2. 
Libusb-win32 is a library that allows userspace application to access USB 
devices on a Win98SE/WinME/Win2k/WinXP/Win Vista/Win 7 OS on x86/x64/IA64.
It is derived from and fully API compatible to libusb available at 
http://libusb.sourceforge.net.
The libusb-win32 libraries/dlls are licensed under the LGPL.
For more information visit the project's web site at:
http://libusb-win32.sourceforge.net
http://sourceforge.net/projects/libusb-win32



